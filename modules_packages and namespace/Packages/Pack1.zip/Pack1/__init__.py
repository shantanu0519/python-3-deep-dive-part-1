print("Executing Pack1")


value = "pack1valuepython"
